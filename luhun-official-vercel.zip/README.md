# Luhun Official

Static storefront for **Luhun Official** — sneakers (kids through size 14), t-shirts, and hoodies.

## Deploy on Vercel

1. Push this folder to a GitHub repo (all files in the **root** of the repo).
2. Go to [vercel.com/new](https://vercel.com/new).
3. Import your GitHub repo.
4. **Framework Preset:** Other
5. **Build Command:** leave empty
6. **Output Directory:** leave empty (`.` — repo root)
7. Click **Deploy**

No build step required.

## Run locally

```bash
npx serve .
```

Open http://localhost:3000

## Store

3373 Princeton Rd Suite 131, Hamilton, Ohio 45011

Instagram: [@nep_barbershop](https://www.instagram.com/nep_barbershop/)
