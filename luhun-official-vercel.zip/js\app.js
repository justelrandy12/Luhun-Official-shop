import {
  PRODUCTS,
  SHOE_SIZES,
  CLOTHING_TYPES,
  formatPrice,
  getProductsByRoute,
  getCollectionTitle,
  getFeaturedProducts,
  CONTAIN_IMAGE_IDS,
} from "./products.js";

const CART_KEY = "luhun-cart";

const SHOP_CATEGORIES = [
  { id: "shoes", label: "Shoes", href: "#/shoes" },
  { id: "tees", label: "T-Shirts", href: "#/clothing/tees" },
  { id: "hoodies", label: "Hoodies", href: "#/clothing/hoodies" },
];

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const viewHome = $("#view-home");
const viewShoesSizes = $("#view-shoes-sizes");
const viewCollection = $("#view-collection");
const featuredGrid = $("#featured-grid");
const collectionGrid = $("#collection-grid");
const collectionTitle = $("#collection-title");
const productCount = $("#product-count");
const breadcrumbs = $("#breadcrumbs");
const emptyState = $("#empty-state");
const cartCountEl = $("#cart-count");
const cartBody = $("#cart-body");
const cartFooter = $("#cart-footer");
const cartTotal = $("#cart-total");
const cartDrawer = $("#cart-drawer");
const toast = $("#toast");

let currentRoute = parseHash();
let collectionProducts = [];

function parseHash() {
  const raw = (location.hash || "#/").slice(1);
  const parts = raw.split("/").filter(Boolean);
  if (parts[0] === "shoes") {
    if (parts[1]) return { view: "shoes", sizeId: parts[1] };
    return { view: "shoes-index" };
  }
  if (parts[0] === "clothing" && parts[1]) {
    return { view: "clothing", clothingId: parts[1] };
  }
  return { view: "home" };
}

function getActiveShopCategory(route) {
  if (route.view === "shoes-index" || route.view === "shoes") return "shoes";
  if (route.view === "clothing" && route.clothingId === "hoodies") return "hoodies";
  if (route.view === "clothing") return "tees";
  return null;
}

function renderShopCategoryNav(route) {
  const active = getActiveShopCategory(route);
  if (!active) return;

  const html = SHOP_CATEGORIES.map((cat) => {
    const isActive = cat.id === active;
    return `<a href="${cat.href}" class="shop-tab${isActive ? " is-active" : ""}"${
      isActive ? ' aria-current="page"' : ""
    }>${cat.label}</a>`;
  }).join("");

  $$(".shop-category-nav").forEach((nav) => {
    nav.innerHTML = html;
  });
}

function renderShoeSizeChips(container, activeSizeId) {
  if (!container) return;
  container.innerHTML = SHOE_SIZES.map((s) => {
    const isActive = s.id === activeSizeId;
    return `<a href="#/shoes/${s.id}" class="size-chip${isActive ? " is-active" : ""}"${
      isActive ? ' aria-current="page"' : ""
    }>${s.label}</a>`;
  }).join("");
}

function buildNavMenus() {
  const shoeLinks = SHOE_SIZES.map(
    (s) => `<li><a href="#/shoes/${s.id}">${s.label}</a></li>`
  ).join("");

  $("#shoes-menu-mobile").innerHTML = shoeLinks;
  $("#footer-shoes-links").innerHTML = SHOE_SIZES.map(
    (s) => `<li><a href="#/shoes/${s.id}">${s.label}</a></li>`
  ).join("");

  renderShoeSizeChips($("#size-chips-shoes"));
}

function renderProductCard(product) {
  const badgeClass =
    product.badge === "sold-out"
      ? "product-badge--sold-out"
      : "product-badge--sale";
  const badgeText = product.soldOut ? "Sold out" : "Sale";
  const sizeLabel =
    product.category === "shoes"
      ? `Size ${product.size}`
      : product.sizes?.join(" · ") ?? "";
  const btnLabel = product.soldOut
    ? "Sold out"
    : product.sizes?.length
      ? "Choose options"
      : "Add to cart";
  const containImg = CONTAIN_IMAGE_IDS.has(product.id);

  return `
    <article class="product-card" data-id="${product.id}">
      <div class="product-card-media${containImg ? " product-card-media--contain" : ""}">
        <span class="product-badge ${badgeClass}">${badgeText}</span>
        <img src="${product.image}" alt="${product.name}" loading="lazy" width="600" height="600"${containImg ? ' class="product-img--contain"' : ""} />
      </div>
      <div class="product-card-body">
        <h3>${product.name}</h3>
        ${sizeLabel ? `<p class="product-card-size" style="margin:0;font-size:0.8rem;color:var(--muted)">${sizeLabel}</p>` : ""}
        <div class="product-price">
          <strong>${formatPrice(product.price)}</strong>
          ${product.compareAt ? `<s>${formatPrice(product.compareAt)}</s>` : ""}
        </div>
        <div class="product-card-actions">
          <button
            type="button"
            class="btn btn-outline add-to-cart"
            data-id="${product.id}"
            ${product.soldOut ? "disabled" : ""}
          >${btnLabel}</button>
        </div>
      </div>
    </article>
  `;
}

function bindProductCards(root) {
  root.querySelectorAll(".add-to-cart").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-id");
      const product = PRODUCTS.find((p) => p.id === id);
      if (!product || product.soldOut) return;

      if (product.sizes?.length > 1) {
        const size = prompt(
          `Select size for ${product.name}:\n${product.sizes.join(", ")}`,
          product.sizes[0]
        );
        if (!size || !product.sizes.includes(size)) {
          showToast("Please pick a valid size.");
          return;
        }
        addToCart(product, size);
      } else {
        const variant =
          product.category === "shoes"
            ? `Size ${product.size}`
            : product.sizes?.[0] ?? "One Size";
        addToCart(product, variant);
      }
    });
  });
}

function renderGrid(container, products) {
  if (!container) return;
  container.innerHTML = products.map(renderProductCard).join("");
  bindProductCards(container);
}

function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartUI();
}

function addToCart(product, variant) {
  const cart = getCart();
  const existing = cart.find(
    (l) => l.id === product.id && l.variant === variant
  );
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      variant,
      qty: 1,
    });
  }
  saveCart(cart);
  showToast(`${product.name} added to cart`);
  openCart();
}

function removeFromCart(index) {
  const cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
}

function cartSubtotal(cart) {
  return cart.reduce((sum, l) => sum + l.price * l.qty, 0);
}

function updateCartUI() {
  const cart = getCart();
  const count = cart.reduce((n, l) => n + l.qty, 0);

  if (count > 0) {
    cartCountEl.textContent = String(count);
    cartCountEl.hidden = false;
  } else {
    cartCountEl.hidden = true;
  }

  if (cart.length === 0) {
    cartBody.innerHTML =
      '<p class="cart-empty">Your cart is empty. <a href="#/shoes/8">Continue shopping</a></p>';
    cartFooter.hidden = true;
    return;
  }

  cartBody.innerHTML = cart
    .map(
      (line, i) => `
    <div class="cart-line">
      <img src="${line.image}" alt="" width="72" height="72" />
      <div>
        <h4>${line.name}</h4>
        <p class="cart-line-meta">${line.variant} · Qty ${line.qty}</p>
        <button type="button" class="cart-remove" data-index="${i}">Remove</button>
      </div>
      <span class="cart-line-price">${formatPrice(line.price * line.qty)}</span>
    </div>
  `
    )
    .join("");

  cartBody.querySelectorAll(".cart-remove").forEach((btn) => {
    btn.addEventListener("click", () => {
      removeFromCart(Number(btn.getAttribute("data-index")));
    });
  });

  cartTotal.textContent = formatPrice(cartSubtotal(cart));
  cartFooter.hidden = false;
}

function openCart() {
  cartDrawer.hidden = false;
  document.body.style.overflow = "hidden";
  $("#cart-close")?.focus();
}

function closeCart() {
  cartDrawer.hidden = true;
  document.body.style.overflow = "";
}

function filterAndSort(products) {
  const avail = $("#filter-availability")?.value ?? "all";
  const sort = $("#filter-sort")?.value ?? "featured";
  let list = [...products];

  if (avail === "in-stock") list = list.filter((p) => !p.soldOut);
  if (avail === "sale") list = list.filter((p) => p.badge === "sale" && !p.soldOut);

  switch (sort) {
    case "price-asc":
      list.sort((a, b) => a.price - b.price);
      break;
    case "price-desc":
      list.sort((a, b) => b.price - a.price);
      break;
    case "name":
      list.sort((a, b) => a.name.localeCompare(b.name));
      break;
    default:
      break;
  }
  return list;
}

function renderCollection() {
  collectionProducts = getProductsByRoute(currentRoute);
  const title = getCollectionTitle(currentRoute);
  collectionTitle.textContent = title;
  renderShopCategoryNav(currentRoute);

  const subnav = $("#collection-subnav");
  if (currentRoute.view === "shoes" && currentRoute.sizeId) {
    subnav.hidden = false;
    subnav.innerHTML =
      '<p class="collection-subnav-label">Shoe size</p><div class="size-chips size-chips--subnav"></div>';
    renderShoeSizeChips($(".size-chips--subnav", subnav), currentRoute.sizeId);
  } else {
    subnav.hidden = true;
    subnav.innerHTML = "";
  }

  const crumbs = [
    `<a href="#/">Home</a>`,
    currentRoute.view === "shoes"
      ? `<span> / </span><a href="#/shoes">Shoes</a>`
      : `<span> / </span><span>Clothing</span>`,
    `<span> / </span><span>${title}</span>`,
  ];
  breadcrumbs.innerHTML = crumbs.join("");

  refreshCollectionGrid();
}

function refreshCollectionGrid() {
  const filtered = filterAndSort(collectionProducts);
  productCount.textContent = `${filtered.length} product${filtered.length === 1 ? "" : "s"}`;
  emptyState.hidden = filtered.length > 0;
  collectionGrid.hidden = filtered.length === 0;
  renderGrid(collectionGrid, filtered);
}

function navigate() {
  currentRoute = parseHash();
  closeMobileMenu();

  if (currentRoute.view === "home") {
    viewHome.hidden = false;
    viewShoesSizes.hidden = true;
    viewCollection.hidden = true;
    document.title = "Luhun Official — Shoes, Tees & Hoodies";
    renderFeatured();
    return;
  }

  if (currentRoute.view === "shoes-index") {
    viewHome.hidden = true;
    viewShoesSizes.hidden = false;
    viewCollection.hidden = true;
    document.title = "Shoes — Luhun Official";
    renderShopCategoryNav(currentRoute);
    window.scrollTo({ top: 0, behavior: "smooth" });
    return;
  }

  viewHome.hidden = true;
  viewShoesSizes.hidden = true;
  viewCollection.hidden = false;
  document.title = `${getCollectionTitle(currentRoute)} — Luhun Official`;
  renderCollection();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderFeatured() {
  renderGrid(featuredGrid, getFeaturedProducts());
}

let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.hidden = false;
  toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.remove("is-visible");
    setTimeout(() => {
      toast.hidden = true;
    }, 400);
  }, 3200);
}

function closeMobileMenu() {
  const nav = $("#mobile-nav");
  const toggle = $("#menu-toggle");
  if (nav && !nav.hidden) {
    nav.hidden = true;
    toggle?.setAttribute("aria-expanded", "false");
  }
}

function initEvents() {
  window.addEventListener("hashchange", navigate);

  $("#menu-toggle")?.addEventListener("click", () => {
    const nav = $("#mobile-nav");
    const open = nav.hidden;
    nav.hidden = !open;
    $("#menu-toggle").setAttribute("aria-expanded", String(open));
  });

  $$("#mobile-nav a, [data-nav]").forEach((a) => {
    a.addEventListener("click", closeMobileMenu);
  });

  $("#filter-availability")?.addEventListener("change", refreshCollectionGrid);
  $("#filter-sort")?.addEventListener("change", refreshCollectionGrid);

  $("#cart-open")?.addEventListener("click", openCart);
  $("#cart-close")?.addEventListener("click", closeCart);
  $("#cart-backdrop")?.addEventListener("click", closeCart);
  $("#cart-continue")?.addEventListener("click", closeCart);

  $("#checkout-btn")?.addEventListener("click", () => {
    const cart = getCart();
    if (!cart.length) return;
    showToast(
      `Demo checkout — ${formatPrice(cartSubtotal(cart))} total. Connect Shopify or Stripe for live payments.`
    );
  });

  $("#newsletter-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = new FormData(e.target).get("email");
    showToast(`Thanks! We'll keep ${email} in the loop.`);
    e.target.reset();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !cartDrawer.hidden) closeCart();
  });
}

function initStoreSlideshow() {
  const slides = $$(".store-slide");
  const dots = $$(".store-dot");
  const counter = $("#store-counter");
  const prev = $("#store-prev");
  const next = $("#store-next");
  if (!slides.length) return;

  let index = 0;
  let timer;

  function goTo(i) {
    index = (i + slides.length) % slides.length;
    slides.forEach((slide, n) => {
      slide.classList.toggle("is-active", n === index);
      slide.setAttribute("aria-hidden", n === index ? "false" : "true");
    });
    dots.forEach((dot, n) => {
      dot.classList.toggle("is-active", n === index);
      dot.setAttribute("aria-selected", n === index ? "true" : "false");
    });
    if (counter) counter.textContent = `${index + 1} / ${slides.length}`;
  }

  function startAutoplay() {
    clearInterval(timer);
    timer = setInterval(() => goTo(index + 1), 6000);
  }

  prev?.addEventListener("click", () => {
    goTo(index - 1);
    startAutoplay();
  });
  next?.addEventListener("click", () => {
    goTo(index + 1);
    startAutoplay();
  });
  dots.forEach((dot) => {
    dot.addEventListener("click", () => {
      goTo(Number(dot.getAttribute("data-goto")));
      startAutoplay();
    });
  });

  slides.forEach((s, n) => s.setAttribute("aria-hidden", n === 0 ? "false" : "true"));
  goTo(0);
  startAutoplay();
}

buildNavMenus();
initEvents();
initStoreSlideshow();
updateCartUI();
navigate();
